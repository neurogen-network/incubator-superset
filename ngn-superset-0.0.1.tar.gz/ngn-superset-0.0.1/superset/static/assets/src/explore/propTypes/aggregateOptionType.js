import PropTypes from 'prop-types';

export default PropTypes.shape({
  aggregate_name: PropTypes.string.isRequired,
});
