"""empty message

Revision ID: 5ccf602336a0
Revises: ('130915240929', 'c9495751e314')
Create Date: 2018-04-12 16:00:47.639218

"""

# revision identifiers, used by Alembic.
revision = '5ccf602336a0'
down_revision = ('130915240929', 'c9495751e314')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
