"""empty message

Revision ID: c9495751e314
Revises: ('30bb17c0dc76', 'bf706ae5eb46')
Create Date: 2018-04-10 20:46:57.890773

"""

# revision identifiers, used by Alembic.
revision = 'c9495751e314'
down_revision = ('30bb17c0dc76', 'bf706ae5eb46')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
