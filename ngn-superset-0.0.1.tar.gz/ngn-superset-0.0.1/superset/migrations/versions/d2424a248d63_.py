# -*- coding: utf-8 -*-
"""empty message

Revision ID: d2424a248d63
Revises: ('a2d606a761d9', '836c0bf75904')
Create Date: 2016-03-22 23:25:02.903273

"""

# revision identifiers, used by Alembic.
revision = 'd2424a248d63'
down_revision = ('a2d606a761d9', '836c0bf75904')


def upgrade():
    pass


def downgrade():
    pass
